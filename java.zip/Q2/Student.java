package Q2;
class Student {
    String name;
    int roll_no;

    // Constructor to initialize name and roll_no
    public Student(String name, int roll_no) {
        this.name = name;
        this.roll_no = roll_no;
    }
}