package Q2;
public class StudentInfo {
    public static void main(String[] args) {
        // Create two objects of the 'Student' class
        Student sam = new Student("Sam", 101);
        Student john = new Student("John", 102);

        // Assign and print the roll numbers, phone numbers, and addresses
        System.out.println("Student Name: " + sam.name);
        System.out.println("Roll Number: " + sam.roll_no);

        System.out.println("Student Name: " + john.name);
        System.out.println("Roll Number: " + john.roll_no);
    }
}
